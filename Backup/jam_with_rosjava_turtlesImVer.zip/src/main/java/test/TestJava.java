package test;

public class TestJava {

	
	public TestJava() {
		System.out.println("instanciation!");
	}
	public int add(int i , int j){
		int k = i+j;
		System.out.println(k);
		return k;
	}
	
	
}
