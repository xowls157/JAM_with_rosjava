package uos.ai.jam.expression;

public enum ValueType {
	VOID,
	LONG,
	REAL,
	STRING,
	OBJECT
}
