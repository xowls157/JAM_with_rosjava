package uos.ai.jam.plan;

public interface PlanLibraryChangeListener {
	public void planAdded(Plan plan);
	public void planRemoved(Plan plan);
}
