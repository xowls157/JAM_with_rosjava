package uos.ai.jam;

public interface IntentionStructureChangeListener {
	public void goalAdded(Goal goal);
	public void goalRemoved(Goal goal);
}
