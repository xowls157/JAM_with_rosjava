package kgu.uos.ai.jam.tutorial;

public class Calculator {
	
	public Calculator() {
		System.out.println("instantiation!");
	}
	public int add(int i , int j){
		int k = i+j;
		return k;
	}
	

}
