package kgu.uos.ai.jam.tutorial;

public class Printer {
	
	public Printer() {
		System.out.println("instantiation!");
	}
	public void print(String str){
		
		System.out.println(str);
	}

}
